class Constantes():
    type_object = {'T-shirt/top':100, 'Trouser':101, 'Pullover':102, 'Dress':103, 'Coat':104,
               'Sandal':105, 'Shirt':106, 'Sneaker':107, 'Bag':108, 'Ankle boot':109}
    type_food = {"conserve": 200, "pâtes": 201, "eau": 203, "autre nourriture": 204, "autre boisson": 205}
    type_housing = [1, 2, 3, 4, 5, 6]